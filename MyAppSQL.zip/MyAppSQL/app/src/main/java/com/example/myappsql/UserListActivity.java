package com.example.myappsql;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class UserListActivity extends AppCompatActivity {

    ListView userListView;
    DatabaseHelper db;
    ArrayList<String> userList;
    ArrayAdapter<String> adapter;
    Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_list);

        userListView = findViewById(R.id.userListView);
        btnBack = findViewById(R.id.btnBack);
        db = new DatabaseHelper(this);
        userList = new ArrayList<>();

        Cursor cursor = db.getAllUsers();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No users found", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                String email = cursor.getString(cursor.getColumnIndexOrThrow("email"));
                String firstName = cursor.getString(cursor.getColumnIndexOrThrow("first_name"));
                String lastName = cursor.getString(cursor.getColumnIndexOrThrow("last_name"));
                userList.add("Email: " + email + "\nName: " + firstName + " " + lastName);
            }

            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, userList);
            userListView.setAdapter(adapter);
        }

        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> {
            Intent intent = new Intent(UserListActivity.this, MainActivity.class);
            startActivity(intent);
        });

    }
}
