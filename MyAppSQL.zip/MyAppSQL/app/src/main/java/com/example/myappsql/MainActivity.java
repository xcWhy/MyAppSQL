package com.example.myappsql;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;


public class MainActivity extends AppCompatActivity {

    TextView tvWelcome;
    EditText etEmail, etFirstName, etLastName;
    Button btnSave;

    DatabaseHelper databaseHelper;
    String userEmail; // we will pass this from SignActivity

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        tvWelcome = findViewById(R.id.tvWelcome);
        etEmail = findViewById(R.id.etEmail);
        etFirstName = findViewById(R.id.etFirstName);
        etLastName = findViewById(R.id.etLastName);
        btnSave = findViewById(R.id.btnSave);

        databaseHelper = new DatabaseHelper(this);

        // Get email from Intent
        userEmail = getIntent().getStringExtra("email");

        // Get user data
        String[] userData = databaseHelper.getUserData(userEmail);
        if (userData != null) {
            String firstName = userData[0];
            String lastName = userData[1];

            etEmail.setText(userEmail);
            etFirstName.setText(firstName);
            etLastName.setText(lastName);
            tvWelcome.setText("Welcome, " + firstName);
        }

        // Save button action
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String updatedFirstName = etFirstName.getText().toString().trim();
                String updatedLastName = etLastName.getText().toString().trim();

                if (updatedFirstName.isEmpty() || updatedLastName.isEmpty()) {
                    Toast.makeText(MainActivity.this, "First and Last name cannot be empty", Toast.LENGTH_SHORT).show();
                } else {
                    boolean updated = databaseHelper.updateUserData(userEmail, updatedFirstName, updatedLastName);
                    if (updated) {
                        Toast.makeText(MainActivity.this, "Profile updated!", Toast.LENGTH_SHORT).show();
                        tvWelcome.setText("Welcome, " + updatedFirstName);
                    } else {
                        Toast.makeText(MainActivity.this, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        Button btnShowUsers = findViewById(R.id.btnShowUsers);
        btnShowUsers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, UserListActivity.class);
                startActivity(intent);
            }
        });
    }
}
