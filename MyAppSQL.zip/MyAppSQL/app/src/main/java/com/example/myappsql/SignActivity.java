package com.example.myappsql;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import com.example.myappsql.databinding.ActivitySignBinding;

public class SignActivity extends AppCompatActivity {

    ActivitySignBinding binding;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySignBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        databaseHelper = new DatabaseHelper(this);

        binding.signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = binding.signupEmail.getText().toString().trim();
                String firstName = binding.signupFirst.getText().toString().trim();
                String lastName = binding.signupLast.getText().toString().trim();

                if (email.isEmpty() || firstName.isEmpty() || lastName.isEmpty()) {
                    Toast.makeText(SignActivity.this, "All fields are required", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean userExists = databaseHelper.checkUserExists(email);
                if (userExists) {
                    Toast.makeText(SignActivity.this, "User already exists", Toast.LENGTH_SHORT).show();
                } else {
                    boolean inserted = databaseHelper.insertUser(email, firstName, lastName);
                    if (inserted) {
                        Toast.makeText(SignActivity.this, "Signup Successful!", Toast.LENGTH_SHORT).show();
                        // Go to HomeActivity and pass the email
                        Intent intent = new Intent(SignActivity.this, MainActivity.class);
                        intent.putExtra("email", email);
                        startActivity(intent);
                        finish(); // Optional: Prevent going back to sign-up with back button
                    } else {
                        Toast.makeText(SignActivity.this, "Signup Failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
